import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(const EventEaseApp());
}

const String API_BASE = "http://10.0.2.2:8000"; 
// 👆 Android Emulator ke liye host. Agar tu apne phone pe test kare, apne PC ka local IP daal (e.g. http://192.168.1.5:8000)

class EventEaseApp extends StatefulWidget {
  const EventEaseApp({super.key});

  @override
  State<EventEaseApp> createState() => _EventEaseAppState();
}

class _EventEaseAppState extends State<EventEaseApp> {
  String token = "";
  List<dynamic> events = [];

  @override
  void initState() {
    super.initState();
    fetchEvents();
  }

  // 🔹 API: Get Events
  Future<void> fetchEvents() async {
    final response = await http.get(Uri.parse("$API_BASE/events"));
    if (response.statusCode == 200) {
      setState(() {
        events = jsonDecode(response.body);
      });
    } else {
      print("Failed to load events: ${response.body}");
    }
  }

  // 🔹 API: Login (Demo user)
  Future<void> login() async {
    final response = await http.post(
      Uri.parse("$API_BASE/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": "test@example.com", "password": "pass123"}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        token = data["access_token"];
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Login successful")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Login failed")),
      );
    }
  }

  // 🔹 API: Book Event
  Future<void> bookEvent(int eventId) async {
    if (token.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please login first")),
      );
      return;
    }

    final response = await http.post(
      Uri.parse("$API_BASE/book/$eventId"),
      headers: {
        "Authorization": "Bearer $token",
      },
    );

    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Booking Successful")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Booking failed: ${response.body}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "EventEase",
      home: Scaffold(
        appBar: AppBar(
          title: const Text("EventEase"),
          centerTitle: true,
          backgroundColor: Colors.blueAccent,
        ),
        body: Column(
          children: [
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: login,
              child: Text(token.isEmpty ? "Login (Demo User)" : "Logged In"),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: events.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: events.length,
                      itemBuilder: (context, index) {
                        final e = events[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          child: ListTile(
                            title: Text(e["title"]),
                            subtitle: Text(
                                "${e["date"].toString().split('T')[0]} • ${e["location"] ?? 'N/A'}"),
                            trailing: ElevatedButton(
                              onPressed: () => bookEvent(e["id"]),
                              child: const Text("Book"),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
