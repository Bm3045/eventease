package com.example.eventease_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
